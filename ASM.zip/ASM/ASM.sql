﻿create database ASM1

create table account( -- tài khoản 
username nvarchar(50) primary key,
password nvarchar(1000),
role nvarchar(50),
);

insert into account values 
(N'Nguyễn Văn Cường',N'123',N'Quản lí'),
(N'Nguyễn Duy Hưng',N'345',N'Thủ kho'),
(N'Nguyễn Tấn Tài',N'678',N'Kinh doanh');


create table category( -- danh mục 
id int identity(1,1) primary key ,
category_name nvarchar(50),
);

select * from category

insert into category values
(N'Điện thoại đắt tiền'),
(N'Điện thoại rẻ tiền');

select * from category

create table product ( -- sản phẩm
id int identity(1,1) primary key ,
category_id int ,
product_name nvarchar(50),
current_price money ,
quantity int ,
ram varchar(50),
screen_type varchar(50),
FOREIGN KEY (category_id) REFERENCES category(id),
);

SELECT * FROM product


insert into product values 
(1,N'Iphone12',100,2,'6gb','OLED'),
(2,N'SamSung3' ,5000,1,'2gb','AMOLED'),
(1,N'IphoneProMax' ,10000,6,'8gb','OLED');

insert into product values 
(1,)


create table inventory_log( -- nhật kí xuất nhập tồn 
product_id int ,
ie_date date ,
ioe bit,
quantity int,
price money,
primary key (product_id,ie_date),
FOREIGN KEY (product_id) REFERENCES product(id),
);

INSERT INTO inventory_log (product_id, ie_date, ioe, quantity, price)
VALUES
(9, '2022-03-01', 1, 2, 100),
(10, '2022-03-02', 0, 1, 5000),
(11, '2022-03-05 ', 1, 4, 800),
(9, '2022-03-08 ', 0, 1, 120), 
(10, '2022-03-10', 1, 3, 6000); 



