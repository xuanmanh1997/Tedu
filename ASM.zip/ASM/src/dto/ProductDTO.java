/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.math.BigDecimal;

/**
 *
 * @author Admin
 */
public class ProductDTO extends model.Product{
    private String categoryName;

    public ProductDTO(Integer id, Integer categoryid, String productname, BigDecimal currentprice, Integer quantity, String ram, String screentype) {
        super(id, categoryid, productname, currentprice, quantity, ram, screentype);
    }

    public ProductDTO() {
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    
}
