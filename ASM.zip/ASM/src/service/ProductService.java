/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.ResultSet;
import java.util.ArrayList;
import model.Product;
import repository.InventoryLogRepository;
import repository.ProductRepository;

/**
 *
 * @author Admin
 */
public class ProductService {

    private ProductRepository productRepository = new ProductRepository();
    private InventoryLogRepository inventoryLogRepository = new InventoryLogRepository();

    public ArrayList<Product> getListProduct() {
        return productRepository.all();
    }

   
    public void deleteByProductId(int productId) {
        inventoryLogRepository.deleteByProductId(productId);
        productRepository.deleteById(productId);
    }
    
  

}
