/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Category;
import model.Product;

/**
 *
 * @author Admin
 */
public class CategoryRepository {
        private static Connection connection = null;

    static {
        try {
            connection = DbConnector.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//    public Category findById(int id) {
//        try {
//            String query = "SELECT * FROM category where id = ?";
//            PreparedStatement ps = connection.prepareStatement(query);
//            ps.setInt(1, id);
//            ps.execute();
//            ResultSet rs = ps.getResultSet();
//            Category category = new Category();
//            category.setId(id);
//            while (rs.next()) {
//                String categoryName = rs.getString("category_name");
//                category.setCategoryName(categoryName);
//            }
//            return category;
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
     public void insert(Category category) {
        try {
            String query = "INSERT INTO category"
                    + "(id,category_name) "
                    + "VALUES (?,?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, category.getId());
            ps.setString(2, category.getCategoryName());         
            ps.execute();
            System.out.println("Thêm thành công trong database");
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
