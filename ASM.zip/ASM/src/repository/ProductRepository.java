/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import dto.ProductDTO;
import java.math.BigDecimal;
import model.Product;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.text.html.parser.DTD;
import java.sql.Statement;

/**
 *
 * @author Admin
 */
public class ProductRepository {

    private final static String PRODUCT_ID = "id";  // 
    private final static String PRODUCT_CATEGORY_ID = "category_id";
    private final static String PRODUCT_NAME = "product_name";
    private final static String PRODUCT_CURRENT_PRICE = "current_price";
    private final static String PRODUCT_QUANTITY = "quantity";
    private final static String PRODUCT_RAM = "ram";
    private final static String PRODUCT_SCREEN_TYPE = "screen_type";

    private static Connection connection = null;

    static {
        try {
            connection = DbConnector.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public ArrayList<Product> all() {
        ArrayList<Product> list = new ArrayList<>();
        try {
            String query = "SELECT * FROM product";
            PreparedStatement ps = connection.prepareStatement(query); // kết nối với sql và thực hiện câu truy vấn 
            ps.execute(); // thực hiện câu lệnh 
            ResultSet rs = ps.getResultSet(); // trả về kết quả của sql trả về 
            while (rs.next()) {
                int Id = rs.getInt(PRODUCT_ID);
                int CategoryId = rs.getInt(PRODUCT_CATEGORY_ID);
                String ProductName = rs.getString(PRODUCT_NAME);
                BigDecimal Price = rs.getBigDecimal(PRODUCT_CURRENT_PRICE);
                int Quantity = rs.getInt(PRODUCT_QUANTITY);
                String Ram = rs.getString(PRODUCT_RAM);
                String ScreenType = rs.getString(PRODUCT_SCREEN_TYPE);
                Product product = new Product(Id, CategoryId, ProductName, Price, Quantity, Ram, ScreenType);
                list.add(product); // áp vào 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void insert(Product product) {
        try {
            String query = "INSERT INTO product"
                    + "(id,category_id,product_name,current_price,quantity,ram,screen_type) "
                    + "VALUES (?, ?, ?, ?,?,?,?,?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, product.getId());
            ps.setInt(2, product.getCategoryid());
            ps.setString(3, product.getProductname());
            ps.setBigDecimal(4, product.getCurrentprice());
            ps.setInt(5, product.getQuantity());
            ps.setString(6, product.getRam());
            ps.setString(7, product.getScreentype());
            ps.execute();
            System.out.println("Thêm thành công trong database");
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteById(int id) {
        try {
            String query = "delete  from product where id =?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setInt(1, id);

            ps.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
