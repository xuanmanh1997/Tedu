/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Account;
import model.Product;
import model.Role;

/**
 *
 * @author Admin
 */
public class AccountRepository {

    private static Connection connection = null;

    static {
        try {
            connection = DbConnector.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public Account getAccountByUsernameAndPassword(String username, String password) {
        try {
            String query = "SELECT * FROM account where username = ? and password = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.execute();
            ResultSet rs = ps.getResultSet();
            while (rs.next()) {
                Account account = new Account();
                account.setUsername(rs.getString("username"));
                account.setPassword(rs.getString("password"));
                account.setRole(Role.valueOf(rs.getString("role")));
                return account; // khi không có user và pass trùng thì nhảy ra return null ;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return null;
    }

}
