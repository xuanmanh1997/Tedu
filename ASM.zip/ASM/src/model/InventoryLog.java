/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author Admin
 */
public class InventoryLog {

    private Integer id;
    private Date iedate;
    private boolean ioe;
    private Integer quantity;
    private BigDecimal price;

    public InventoryLog(Integer id, Date iedate, boolean ioe, Integer quantity, BigDecimal price) {
        this.id = id;
        this.iedate = iedate;
        this.ioe = ioe;
        this.quantity = quantity;
        this.price = price;
    }

    public InventoryLog() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getIedate() {
        return iedate;
    }

    public void setIedate(Date iedate) {
        this.iedate = iedate;
    }

    public boolean isIoe() {
        return ioe;
    }

    public void setIoe(boolean ioe) {
        this.ioe = ioe;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

  
}
